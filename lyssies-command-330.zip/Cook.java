public class Cook {
    public Cook() {}
    public void makeBurger() {
        System.out.println("Cook is making a burger");
    }
    public void makeMilkshake() {
        System.out.println("Cook is making a burger");
    }
}