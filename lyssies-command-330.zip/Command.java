interface Command {
    public void execute();
}